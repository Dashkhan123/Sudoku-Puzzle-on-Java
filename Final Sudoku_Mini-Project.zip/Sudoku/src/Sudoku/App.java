package Sudoku;

public class App
{
    public static void main(String[] args)
    {
        Sudoku sudoku = new Sudoku();
        Tile t = new Tile(0,0);
    }
}