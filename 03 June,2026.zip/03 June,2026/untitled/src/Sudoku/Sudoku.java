package Sudoku;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Sudoku
{

    // OOP: Encapsulates error tracking logic
    class ErrorTracker
    {
        private int errors = 0;

        void increment()
        {
            errors += 1;
        }

        void decrement()
        {
            if (errors > 0) errors -= 1;
        }

        int getErrors()
        {
            return errors;
        }
    }

    // OOP: Encapsulates puzzle data and board-related logic
    class PuzzleBoard
    {
        private String[] puzzle = {
                "--74916-5",
                "2---6-3-9",
                "-----7-1-",
                "-586----4",
                "--3----9-",
                "--62--187",
                "9-4-7---2",
                "67-83----",
                "81--45---"
        };

        private String[] solution = {
                "387491625",
                "241568379",
                "569327418",
                "758619234",
                "123784596",
                "496253187",
                "934176852",
                "675832941",
                "812945763"
        };

        char getPuzzleChar(int r, int c)
        {
            return puzzle[r].charAt(c);
        }

        String getSolutionChar(int r, int c)
        {
            return String.valueOf(solution[r].charAt(c));
        }

        boolean isCorrect(int r, int c, String input)
        {
            return getSolutionChar(r, c).equals(input);
        }
    }

    class Tile extends JButton
    {
        int r;
        int c;
        Tile(int r, int c)
        {
            this.r = r;
            this.c = c;
        }
    }

    int boardWidth = 600;
    int boardHeight = 650;

    // OOP: Using class instances instead of raw fields
    PuzzleBoard puzzleBoard = new PuzzleBoard();
    ErrorTracker errorTracker = new ErrorTracker();

    JFrame frame = new JFrame("Sudoku");
    JLabel textLabel = new JLabel();
    JPanel textPanel = new JPanel();
    JPanel boardPanel = new JPanel();
    JPanel buttonsPanel = new JPanel();

    JButton numSelected = null;

    Sudoku()
    {
        frame.setSize(boardWidth, boardHeight);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        textLabel.setFont(new Font("Arial", Font.BOLD, 20));
        textLabel.setHorizontalAlignment(JLabel.CENTER);
        textLabel.setText("Sudoku: 0");

        textPanel.add(textLabel);
        frame.add(textPanel, BorderLayout.NORTH);

        boardPanel.setLayout(new GridLayout(9, 9));
        setupTiles();
        frame.add(boardPanel, BorderLayout.CENTER);

        buttonsPanel.setLayout(new GridLayout(1, 9));
        setupButtons();
        frame.add(buttonsPanel, BorderLayout.SOUTH);
        frame.setVisible(true);
    }

    // Checks if all tiles on the board are filled
    boolean isBoardComplete()
    {
        for (Component comp : boardPanel.getComponents())
        {
            if (comp instanceof Tile)
            {
                Tile t = (Tile) comp;
                if (t.getText().equals(""))
                {
                    return false;
                }
            }
        }
        return true;
    }

    void setupTiles()
    {
        for (int r = 0; r < 9; r++)
        {
            for (int c = 0; c < 9; c++)
            {
                Tile tile = new Tile(r, c);
                char tileChar = puzzleBoard.getPuzzleChar(r, c);

                if (tileChar != '-')
                {
                    tile.setFont(new Font("Arial", Font.BOLD, 20));
                    tile.setText(String.valueOf(tileChar));
                    tile.setBackground(Color.lightGray);
                }
                else
                {
                    tile.setFont(new Font("Arial", Font.PLAIN, 20));
                    tile.setBackground(Color.white);
                }

                if ((r == 2 && c == 2) || (r == 2 && c == 5) || (r == 5 && c == 2) || (r == 5 && c == 5))
                {
                    tile.setBorder(BorderFactory.createMatteBorder(1, 1, 5, 5, Color.BLACK));
                }
                else if (r == 2 || r == 5)
                {
                    tile.setBorder(BorderFactory.createMatteBorder(1, 1, 5, 1, Color.BLACK));
                }
                else if (c == 2 || c == 5)
                {
                    tile.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 5, Color.BLACK));
                }
                else
                {
                    tile.setBorder(BorderFactory.createLineBorder(Color.black));
                }

                tile.setFocusable(false);
                boardPanel.add(tile);

                tile.addActionListener(new ActionListener()
                {
                    @Override
                    public void actionPerformed(ActionEvent e)
                    {
                        Tile tile = (Tile) e.getSource();
                        int r = tile.r;
                        int c = tile.c;

                        if (numSelected != null)
                        {
                            if (!tile.getText().equals(""))
                            {
                                return;
                            }

                            String numSelectedText = numSelected.getText();

                            if (puzzleBoard.isCorrect(r, c, numSelectedText))
                            {
                                tile.setText(numSelectedText);
                                // Correct answer: decrement errors if any exist
                                errorTracker.decrement();
                                textLabel.setText("Sudoku: " + errorTracker.getErrors());

                                // Check if board is fully complete
                                if (isBoardComplete())
                                {
                                    if (errorTracker.getErrors() > 0)
                                    {
                                        textLabel.setText("Completed, but partially");
                                    }
                                    else
                                    {
                                        textLabel.setText("Congratulations, You have completed the Sudoku Puzzle!");
                                    }
                                }
                            }
                            else
                            {
                                errorTracker.increment();
                                textLabel.setText("Sudoku: " + errorTracker.getErrors());
                            }
                        }
                    }
                });
            }
        }
    }

    void setupButtons()
    {
        for (int i = 0; i < 9; i++)
        {
            JButton button = new JButton();
            button.setFont(new Font("Arial", Font.BOLD, 20));
            button.setText(String.valueOf(i));
            button.setFocusable(false);
            button.setBackground(Color.white);
            buttonsPanel.add(button);

            button.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    JButton button = (JButton) e.getSource();
                    if (numSelected != null)
                    {
                        numSelected.setBackground(Color.white);
                    }
                    numSelected = button;
                    numSelected.setBackground(Color.lightGray);
                }
            });
        }
    }
}






//package Sudoku;
//
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//
//public class Sudoku
//{
//   class Tile extends  JButton
//    {
//        int r;
//        int c;
//        Tile(int r,int c)
//        {
//            this.r=r;
//            this.c=c;
//        }
//    }
//
//    int boardWidth=600;
//    int boardHeight=650;
//
//    String[] puzzle = {
//            "--74916-5",
//            "2---6-3-9",
//            "-----7-1-",
//            "-586----4",
//            "--3----9-",
//            "--62--187",
//            "9-4-7---2",
//            "67-83----",
//            "81--45---"
//    };
//
//    String[] solution = {
//            "387491625",
//            "241568379",
//            "569327418",
//            "758619234",
//            "123784596",
//            "496253187",
//            "934176852",
//            "675832941",
//            "812945763"
//    };
//
//    JFrame frame = new JFrame("Sudoku");
//    JLabel textLabel = new JLabel();
//    JPanel textPanel = new JPanel();
//    JPanel boardPanel = new JPanel();
//    JPanel buttonsPanel = new JPanel();
//
//    JButton numSelected=null;
//    int errors=0;
//
//    Sudoku()
//    {
//        //frame.setVisible(true);
//        frame.setSize(boardWidth,boardHeight);
//        frame.setResizable(false);
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.setLocationRelativeTo(null);
//        frame.setLayout(new BorderLayout());
//
//
//        textLabel.setFont(new Font("Arial", Font.BOLD, 20));
//        textLabel.setHorizontalAlignment(JLabel.CENTER);
//        textLabel.setText("Sudoku:0");
//
//        textPanel.add(textLabel);
//        frame.add(textPanel,BorderLayout.NORTH);
//
//        boardPanel.setLayout(new GridLayout(9,9));
//        setupTiles();
//        frame.add(boardPanel,BorderLayout.CENTER);
//
//
//        buttonsPanel.setLayout(new GridLayout(1,9));
//        setupButtons();
//        frame.add(buttonsPanel,BorderLayout.SOUTH);
//        frame.setVisible(true);
//    }
//
//    void setupTiles()
//    {
//        for (int r = 0; r < 9; r++)
//        {
//            for (int c = 0; c < 9; c++)
//            {
//                Tile tile = new Tile(r,c);
//                char tileChar=puzzle[r].charAt(c);
//
//                if(tileChar !='-')
//                {
//                    tile.setFont(new Font("Arial", Font.BOLD, 20));
//                    tile.setText(String.valueOf(tileChar));
//                    tile.setBackground(Color.lightGray);
//                }
//                else
//                {
//                    tile.setFont(new Font("Arial", Font.PLAIN, 20));
//                    tile.setBackground(Color.white);
//                }
//                if((r==2 && c==2) || (r==2 &&c==5) || (r==5 && c==2 ) || (r==5 && c==5))
//                {
//                    tile.setBorder(BorderFactory.createMatteBorder(1,1,5,5 ,Color.BLACK));
//                }
//                else if(r==2 || r==5)
//                {
//                    tile.setBorder(BorderFactory.createMatteBorder(1,1,5,1,Color.BLACK));
//                }
//                else if(c==2 || c==5)
//                {
//                    tile.setBorder(BorderFactory.createMatteBorder(1,1,1,5,Color.BLACK));
//                }
//                else
//                {
//                    tile.setBorder(BorderFactory.createLineBorder(Color.black));
//                }
//                tile.setFocusable(false);
//                boardPanel.add(tile);
//
//
//                tile.addActionListener(new ActionListener()
//                {
//                    @Override
//                    public void actionPerformed(ActionEvent e)
//                    {
//                        Tile tile=(Tile)e.getSource();
//                        int r=tile.r;
//                        int c=tile.c;
//                        if(numSelected!=null)
//                        {
//                            if(tile.getText()!="")
//                            {
//                                return;
//                            }
//                            String numSelectedText= numSelected.getText();
//                            String tileSolution=String.valueOf(solution[r].charAt(c));
//                            if(tileSolution.equals(numSelectedText))
//                            {
//                                tile.setText(numSelectedText);
//                            }
//                            else
//                            {
//                                errors +=1;
//                                textLabel.setText("Sudoku:"+String.valueOf(errors));
//                            }
//                        }
//                    }
//                });
//            }
//        }
//    }
//    void setupButtons()
//    {
//        for(int i = 0; i < 9; i++)
//        {
//            JButton button = new JButton();
//            button.setFont(new Font("Arial", Font.BOLD, 20) );
//            button.setText(String.valueOf(i));
//            button.setFocusable(false);
//            button.setBackground(Color.white);
//            buttonsPanel.add(button);
//
//            button.addActionListener(new ActionListener()
//            {
//                @Override
//                public void actionPerformed(ActionEvent e)
//                {
//                    JButton button = (JButton)e.getSource();
//                    if(numSelected!=null)
//                    {
//                        numSelected.setBackground(Color.white);
//                    }
//                    numSelected = button;
//                    numSelected.setBackground(Color.lightGray);
//                }
//            });
//        }
//    }
//}